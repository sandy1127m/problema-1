import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-app',
  templateUrl: './add-app.component.html',
  styleUrls: ['./add-app.component.css']
})
export class AddAppComponent implements OnInit {
  
  resultado: string;
  public datos: Array<string>=[];

  RegistroUsuario = new FormGroup({
    id: new FormControl('', [Validators.required,Validators.min(99),Validators.max(105)]),
    nombre: new FormControl('',[Validators.required]),
    genero: new FormControl('',[Validators.required]),
    fechanac: new FormControl('',[Validators.required,Validators.min(1980),Validators.max(2010)])
  });

  submit() {
    if (this.RegistroUsuario.valid){
      
      this.resultado = "Los datos ingresados son válidos";
      console.log("Aqui va mi arreglo")
    console.log(this.RegistroUsuario.get('id').value,this.RegistroUsuario.get('nombre').value,
    this.RegistroUsuario.get('genero').value,this.RegistroUsuario.get('fechanac').value);
    
    this.datos.push(this.RegistroUsuario.get('id').value,this.RegistroUsuario.get('nombre').value,
    this.RegistroUsuario.get('genero').value,this.RegistroUsuario.get('fechanac').value);
    }
    else
      this.resultado = "Los datos ingresados no son válidos";
  }
  
  constructor() {
   
   }

  ngOnInit(): void {
  }
}
