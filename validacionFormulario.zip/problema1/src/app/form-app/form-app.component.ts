import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-app',
  templateUrl: './form-app.component.html',
  styleUrls: ['./form-app.component.css']
})
export class FormAppComponent implements OnInit {
  resultado: string;
  public datos: Array<object>=[];

  RegistroUsuario = new FormGroup({
    nombre: new FormControl('', [Validators.required]),
    apellidos: new FormControl('',[Validators.required]),
    fechanac: new FormControl('',[Validators.required]),
    genero: new FormControl('',[Validators.required]),
    mail: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('',[Validators.required])
  });
  submit() {
    if (this.RegistroUsuario.valid)
      
      this.resultado = "Los datos ingresados son válidos";

    if(this.RegistroUsuario.valid){
    
  }
    else
      this.resultado = "Los datos ingresados no son válidos";
  }
  constructor() { }

  ngOnInit(): void {
  }

}
