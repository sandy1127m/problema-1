import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { SaludarComponent } from './componentes/saludar.component';
import { FormAppComponent } from './form-app/form-app.component';
import { AddAppComponent } from './add-app/add-app.component';

const ENTRYCOMPONENTS = [
  AddAppComponent
];

const COMPONENTS = [AppComponent];

@NgModule({
  declarations: [
    AppComponent,
    SaludarComponent,
    FormAppComponent,
    AddAppComponent,
    ENTRYCOMPONENTS
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [ENTRYCOMPONENTS]
})
export class AppModule { }
