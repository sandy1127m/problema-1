import { Component, ComponentFactoryResolver, ComponentFactory, ViewContainerRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {AddAppComponent} from 'src/app/add-app/add-app.component'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'prueba1';
  name= 'Marc';
  nombreLista='';
  i = 0;
  tabs = [
    {
      component: AddAppComponent
    }
  ]

  public compfact: Array<ComponentFactoryResolver>=[];
  public compview:Array<ViewContainerRef>=[];
  
  constructor(private componentFactoryResolver: ComponentFactoryResolver,
    private viewContainerRef: ViewContainerRef) {

}

CargarComponente(i) {
this.i = i;
const factory = this.componentFactoryResolver.resolveComponentFactory(this.tabs[i].component);
const ref = this.viewContainerRef.createComponent(factory);
}  
 
  onSaludar(mensaje){
console.log(mensaje);
  }
}
