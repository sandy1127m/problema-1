import {Component, Input, Output, EventEmitter} from '@angular/core';



@Component({
    selector: 'saludar-app',
    templateUrl: './saludar.component.html',
    styleUrls: ['./saludar.component.css'] 
    
}
)

export class SaludarComponent{
@Input() nombre:string ="Sandra";
@Output() saludar: EventEmitter<string> = new EventEmitter<string>();

public nombreLista:Object=null;
public nombres: Array<Object> = [];


constructor(){
 
}
onClick(){
    this.saludar.emit('Hola desde el componente hijo!');
}

onButtonClick(){
   // this.nombreLista= document.forms.namedItem('nombreLista');
   this.nombreLista=(<HTMLInputElement>document.getElementById('nombreLista')).value; 
   //console.log(this.nombreLista);
  this.nombres.push(this.nombreLista);  
    //this.nombres.push(this.nombreLista);
    this.nombreLista='';
    //console.log(this.nombreLista);
    console.log(this.nombres);
}
}

